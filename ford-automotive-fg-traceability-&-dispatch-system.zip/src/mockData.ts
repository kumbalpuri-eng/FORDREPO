import { ProductMaster, CustomerMaster, MotherBox, FGProduct, DispatchBatch, SisterConcernDispatchBatch } from './types';

export const INITIAL_PRODUCTS: ProductMaster[] = [
  {
    id: 'PROD-001',
    partNumber: 'ETB-PTH-T6-EXP',
    name: 'ETB Panther T6 (Export)',
    category: 'ETB Export Series',
    boxCapacity: 480,
    unit: 'Pieces',
    weightKg: 1.45,
    description: 'Electronic Throttle Body - Panther T6 Export Specification (480 pcs/box)'
  },
  {
    id: 'PROD-002',
    partNumber: 'ETB-PTH-EXP',
    name: 'ETB Panther (Export)',
    category: 'ETB Export Series',
    boxCapacity: 420,
    unit: 'Pieces',
    weightKg: 1.40,
    description: 'Electronic Throttle Body - Panther Standard Export (420 pcs/box)'
  },
  {
    id: 'PROD-003',
    partNumber: 'ETB-PTH-PH2-EXP',
    name: 'ETB Panther Ph2 (Export)',
    category: 'ETB Export Series',
    boxCapacity: 420,
    unit: 'Pieces',
    weightKg: 1.42,
    description: 'Electronic Throttle Body - Panther Phase 2 Export (420 pcs/box)'
  },
  {
    id: 'PROD-004',
    partNumber: 'ETB-FOX-UPG-EXP',
    name: 'ETB Fox Upgrade (Export)',
    category: 'ETB Export Series',
    boxCapacity: 480,
    unit: 'Pieces',
    weightKg: 1.35,
    description: 'Electronic Throttle Body - Fox Upgrade Export (480 pcs/box)'
  },
  {
    id: 'PROD-005',
    partNumber: 'ETB-FOX-CLS-EXP',
    name: 'ETB Fox Classic (Export)',
    category: 'ETB Export Series',
    boxCapacity: 672,
    unit: 'Pieces',
    weightKg: 1.30,
    description: 'Electronic Throttle Body - Fox Classic High Density Export (672 pcs/box)'
  },
  {
    id: 'PROD-006',
    partNumber: 'ETB-PSA-EXP',
    name: 'ETB PSA (Export)',
    category: 'ETB Export Series',
    boxCapacity: 336,
    unit: 'Pieces',
    weightKg: 1.50,
    description: 'Electronic Throttle Body - PSA Group Export Platform (336 pcs/box)'
  },
  {
    id: 'PROD-007',
    partNumber: 'FORD-SIG-EDRE-DRG',
    name: 'FORD Sigma EDR-E Dragon',
    category: 'Ford Powertrain',
    boxCapacity: 240,
    unit: 'Pieces',
    weightKg: 1.65,
    description: 'Throttle Body Assembly - FORD Sigma EDR-E Dragon Engine (240 pcs/box)'
  },
  {
    id: 'PROD-008',
    partNumber: 'ETB-PTH-DOM',
    name: 'ETB Panther',
    category: 'ETB Domestic Series',
    boxCapacity: 360,
    unit: 'Pieces',
    weightKg: 1.38,
    description: 'Electronic Throttle Body - Panther Domestic Platform (360 pcs/box)'
  },
  {
    id: 'PROD-009',
    partNumber: 'TEST-DUMMY-02',
    name: 'Dummy for testing',
    category: 'Testing & Validation',
    boxCapacity: 2,
    unit: 'Pieces',
    weightKg: 0.50,
    description: 'Quick cycle testing and scanner calibration dummy unit (2 pcs/box)'
  }
];

export const INITIAL_CUSTOMERS: CustomerMaster[] = [
  {
    id: 'CUST-001',
    name: 'CEP - Craiova Engine / FWSTA /95 | ROMANIA',
    code: 'CEP-95-RO',
    email: 'craiova.engine.qa@ford.example.com',
    address: 'Strada Henry Ford 29, 200745 Craiova, Dolj',
    city: 'Craiova, Romania',
    contactPerson: 'Craiova Inward QA & Engine Assembly Line',
    phone: '+40 372 581 000',
    isSisterConcern: false
  },
  {
    id: 'CUST-002',
    name: 'DEP - Dagenham Engine Panther Diesel / 0117A /144 | ENGLAND',
    code: 'DEP-144-UK',
    email: 'dagenham.panther.qa@ford.example.com',
    address: 'Chequers Lane, Dagenham, Essex RM9 6PR',
    city: 'Dagenham, England',
    contactPerson: 'Panther Diesel Powertrain QA Lead',
    phone: '+44 20 8592 3000',
    isSisterConcern: false
  },
  {
    id: 'CUST-003',
    name: 'Horizon Inter-Plant Logistics Hub GmbH (European Hub - Germany)',
    code: 'HUB-DE-01',
    email: 'logistik.stuttgart@horizon-hub.de',
    address: 'Industriestraße 12, 70565 Stuttgart, Deutschland',
    city: 'Stuttgart, Germany',
    contactPerson: 'Hans Schmidt (European Logistics Head)',
    phone: '+49 711 4902-880',
    isSisterConcern: true
  },
  {
    id: 'CUST-004',
    name: 'IEP - Eskisehir Engine / D1D4H /164 | TURKEY',
    code: 'IEP-164-TR',
    email: 'eskisehir.engine.qa@fordotosan.example.com',
    address: 'İnönü Fabrikası, Eskişehir-Bilecik Yolu 15. km, İnönü',
    city: 'Eskişehir, Turkey',
    contactPerson: 'Ford Otosan Engine QA Inward',
    phone: '+90 222 213 8000',
    isSisterConcern: false
  },
  {
    id: 'CUST-005',
    name: 'ZAF - Struandale Engine /43 | S. AFRICA',
    code: 'ZAF-43-ZA',
    email: 'struandale.engine.qa@ford.example.com',
    address: 'Struandale Industrial Area, Gqeberha (Port Elizabeth) 6001',
    city: 'Struandale, South Africa',
    contactPerson: 'Struandale Powertrain Inward QA',
    phone: '+27 41 403 2111',
    isSisterConcern: false
  }
];

export const INITIAL_PRODUCTS_FG: FGProduct[] = [
  // Box 1 items (Direct Sale to CEP - Craiova Engine / FWSTA /95 | ROMANIA - Dummy for Testing)
  {
    serialNumber: 'FG-DUMMY-20260901-001',
    productId: 'PROD-009',
    productName: 'Dummy for testing',
    partNumber: 'TEST-DUMMY-02',
    productionDate: '2026-09-01',
    productionShift: 'Shift A',
    boxId: 'BOX-20260901-DUM-001',
    scannedAt: '2026-09-01 09:14:20',
    status: 'DISPATCHED_DIRECT'
  },
  {
    serialNumber: 'FG-DUMMY-20260901-002',
    productId: 'PROD-009',
    productName: 'Dummy for testing',
    partNumber: 'TEST-DUMMY-02',
    productionDate: '2026-09-01',
    productionShift: 'Shift A',
    boxId: 'BOX-20260901-DUM-001',
    scannedAt: '2026-09-01 09:15:02',
    status: 'DISPATCHED_DIRECT'
  },

  // Box 2 items (Dispatched to Sister Concern -> Final Customer DEP - Dagenham Engine Panther Diesel | ENGLAND - ETB Panther Export)
  {
    serialNumber: 'FG-PTH-20260902-101',
    productId: 'PROD-002',
    productName: 'ETB Panther (Export)',
    partNumber: 'ETB-PTH-EXP',
    productionDate: '2026-09-02',
    productionShift: 'Shift B',
    boxId: 'BOX-20260902-PTH-002',
    scannedAt: '2026-09-02 14:10:10',
    status: 'DELIVERED_TO_CUSTOMER'
  },
  {
    serialNumber: 'FG-PTH-20260902-102',
    productId: 'PROD-002',
    productName: 'ETB Panther (Export)',
    partNumber: 'ETB-PTH-EXP',
    productionDate: '2026-09-02',
    productionShift: 'Shift B',
    boxId: 'BOX-20260902-PTH-002',
    scannedAt: '2026-09-02 14:10:55',
    status: 'DELIVERED_TO_CUSTOMER'
  },

  // Box 3 items (At Sister Concern - ETB Fox Upgrade Export)
  {
    serialNumber: 'FG-FOX-20260903-201',
    productId: 'PROD-004',
    productName: 'ETB Fox Upgrade (Export)',
    partNumber: 'ETB-FOX-UPG-EXP',
    productionDate: '2026-09-03',
    productionShift: 'Shift A',
    boxId: 'BOX-20260903-FOX-003',
    scannedAt: '2026-09-03 10:20:00',
    status: 'DISPATCHED_TO_SISTER_CONCERN'
  },
  {
    serialNumber: 'FG-FOX-20260903-202',
    productId: 'PROD-004',
    productName: 'ETB Fox Upgrade (Export)',
    partNumber: 'ETB-FOX-UPG-EXP',
    productionDate: '2026-09-03',
    productionShift: 'Shift A',
    boxId: 'BOX-20260903-FOX-003',
    scannedAt: '2026-09-03 10:20:30',
    status: 'DISPATCHED_TO_SISTER_CONCERN'
  },

  // Box 4 items (In Warehouse Stock - FORD Sigma EDR-E Dragon)
  {
    serialNumber: 'FG-FRD-20260908-301',
    productId: 'PROD-007',
    productName: 'FORD Sigma EDR-E Dragon',
    partNumber: 'FORD-SIG-EDRE-DRG',
    productionDate: '2026-09-08',
    productionShift: 'Shift A',
    boxId: 'BOX-20260908-FRD-004',
    scannedAt: '2026-09-08 07:45:10',
    status: 'PACKED'
  },
  {
    serialNumber: 'FG-FRD-20260908-302',
    productId: 'PROD-007',
    productName: 'FORD Sigma EDR-E Dragon',
    partNumber: 'FORD-SIG-EDRE-DRG',
    productionDate: '2026-09-08',
    productionShift: 'Shift A',
    boxId: 'BOX-20260908-FRD-004',
    scannedAt: '2026-09-08 07:46:00',
    status: 'PACKED'
  },

  // Box 5 items (In Warehouse Stock - Dummy for testing, capacity 2)
  {
    serialNumber: 'FG-DUMMY-20260909-401',
    productId: 'PROD-009',
    productName: 'Dummy for testing',
    partNumber: 'TEST-DUMMY-02',
    productionDate: '2026-09-09',
    productionShift: 'Shift A',
    boxId: 'BOX-20260909-DUM-005',
    scannedAt: '2026-09-09 08:30:10',
    status: 'PACKED'
  },
  {
    serialNumber: 'FG-DUMMY-20260909-402',
    productId: 'PROD-009',
    productName: 'Dummy for testing',
    partNumber: 'TEST-DUMMY-02',
    productionDate: '2026-09-09',
    productionShift: 'Shift A',
    boxId: 'BOX-20260909-DUM-005',
    scannedAt: '2026-09-09 08:30:45',
    status: 'PACKED'
  }
];

export const INITIAL_BOXES: MotherBox[] = [
  {
    id: 'BOX-20260901-DUM-001',
    productId: 'PROD-009',
    productName: 'Dummy for testing',
    partNumber: 'TEST-DUMMY-02',
    boxCapacity: 2,
    productionDate: '2026-09-01',
    packedAt: '2026-09-01 09:16:15',
    packedBy: 'Nagesh Patil',
    itemSerials: [
      'FG-DUMMY-20260901-001',
      'FG-DUMMY-20260901-002'
    ],
    status: 'DISPATCHED_DIRECT',
    dispatchType: 'DIRECT_SALE',
    factoryInvoiceNumber: 'SAP-INV-98102',
    factoryDispatchDate: '2026-09-01',
    initialRecipientId: 'CUST-001',
    initialRecipientName: 'CEP - Craiova Engine / FWSTA /95 | ROMANIA'
  },
  {
    id: 'BOX-20260902-PTH-002',
    productId: 'PROD-002',
    productName: 'ETB Panther (Export)',
    partNumber: 'ETB-PTH-EXP',
    boxCapacity: 420,
    productionDate: '2026-09-02',
    packedAt: '2026-09-02 14:11:00',
    packedBy: 'Nagesh Patil',
    itemSerials: [
      'FG-PTH-20260902-101',
      'FG-PTH-20260902-102'
    ],
    status: 'DISPATCHED_FINAL_CUSTOMER',
    dispatchType: 'SISTER_CONCERN',
    factoryInvoiceNumber: 'SAP-IC-77401',
    factoryDispatchDate: '2026-09-02',
    initialRecipientId: 'CUST-003',
    initialRecipientName: 'Horizon Inter-Plant Logistics Hub GmbH (European Hub - Germany)',
    sisterConcernInvoiceNumber: 'SC-INV-2026-8802',
    sisterConcernDispatchDate: '2026-09-04',
    finalCustomerId: 'CUST-002',
    finalCustomerName: 'DEP - Dagenham Engine Panther Diesel / 0117A /144 | ENGLAND',
    finalCustomerEmail: 'dagenham.panther.qa@ford.example.com'
  },
  {
    id: 'BOX-20260903-FOX-003',
    productId: 'PROD-004',
    productName: 'ETB Fox Upgrade (Export)',
    partNumber: 'ETB-FOX-UPG-EXP',
    boxCapacity: 480,
    productionDate: '2026-09-03',
    packedAt: '2026-09-03 10:22:20',
    packedBy: 'Nagesh Patil',
    itemSerials: [
      'FG-FOX-20260903-201',
      'FG-FOX-20260903-202'
    ],
    status: 'AT_SISTER_CONCERN',
    dispatchType: 'SISTER_CONCERN',
    factoryInvoiceNumber: 'SAP-IC-77402',
    factoryDispatchDate: '2026-09-03',
    initialRecipientId: 'CUST-003',
    initialRecipientName: 'Horizon Inter-Plant Logistics Hub GmbH (European Hub - Germany)'
  },
  {
    id: 'BOX-20260908-FRD-004',
    productId: 'PROD-007',
    productName: 'FORD Sigma EDR-E Dragon',
    partNumber: 'FORD-SIG-EDRE-DRG',
    boxCapacity: 240,
    productionDate: '2026-09-08',
    packedAt: '2026-09-08 07:46:10',
    packedBy: 'Nagesh Patil',
    itemSerials: [
      'FG-FRD-20260908-301',
      'FG-FRD-20260908-302'
    ],
    status: 'PACKED_IN_STOCK'
  },
  {
    id: 'BOX-20260909-DUM-005',
    productId: 'PROD-009',
    productName: 'Dummy for testing',
    partNumber: 'TEST-DUMMY-02',
    boxCapacity: 2,
    productionDate: '2026-09-09',
    packedAt: '2026-09-09 08:31:00',
    packedBy: 'Nagesh Patil',
    itemSerials: [
      'FG-DUMMY-20260909-401',
      'FG-DUMMY-20260909-402'
    ],
    status: 'PACKED_IN_STOCK'
  }
];

export const INITIAL_DISPATCHES: DispatchBatch[] = [
  {
    id: 'DISP-001',
    invoiceNumber: 'SAP-INV-98102',
    dispatchType: 'DIRECT_SALE',
    dispatchDate: '2026-09-01',
    customerId: 'CUST-001',
    customerName: 'CEP - Craiova Engine / FWSTA /95 | ROMANIA',
    customerEmail: 'craiova.engine.qa@ford.example.com',
    customerAddress: 'Strada Henry Ford 29, 200745 Craiova, Dolj, Romania',
    boxIds: ['BOX-20260901-DUM-001'],
    vehicleNumber: 'MH-12-RN-4890',
    notes: 'Direct OEM delivery for Line 2 module assembly',
    createdBy: 'Dadasaheb',
    createdAt: '2026-09-01 11:30:00'
  },
  {
    id: 'DISP-002',
    invoiceNumber: 'SAP-IC-77401',
    dispatchType: 'SISTER_CONCERN',
    dispatchDate: '2026-09-02',
    customerId: 'CUST-003',
    customerName: 'Horizon Inter-Plant Logistics Hub GmbH (European Hub - Germany)',
    customerEmail: 'logistik.stuttgart@horizon-hub.de',
    customerAddress: 'Industriestraße 12, 70565 Stuttgart, Deutschland',
    boxIds: ['BOX-20260902-PTH-002', 'BOX-20260903-FOX-003'],
    vehicleNumber: 'GJ-01-CV-7821',
    notes: 'Inter-Plant stock transfer for European regional distribution',
    createdBy: 'Dadasaheb',
    createdAt: '2026-09-03 12:00:00'
  }
];

export const INITIAL_SC_DISPATCHES: SisterConcernDispatchBatch[] = [
  {
    id: 'SCDISP-001',
    scInvoiceNumber: 'SC-INV-2026-8802',
    factoryInvoiceReference: 'SAP-IC-77401',
    dispatchDate: '2026-09-04',
    finalCustomerId: 'CUST-002',
    finalCustomerName: 'DEP - Dagenham Engine Panther Diesel / 0117A /144 | ENGLAND',
    finalCustomerEmail: 'dagenham.panther.qa@ford.example.com',
    finalCustomerAddress: 'Chequers Lane, Dagenham, Essex RM9 6PR, England',
    boxIds: ['BOX-20260902-PTH-002'],
    vehicleNumber: 'KA-04-E-3399',
    notes: 'Dispatched from European Logistics Hub to Dagenham Engine Panther Diesel Line',
    createdBy: 'Hans Schmidt',
    createdAt: '2026-09-04 15:45:00'
  }
];

export const INITIAL_AUDIT_LOGS = [
  {
    id: 'AUD-001',
    timestamp: '2026-09-01 09:16:15',
    actionType: 'BOX_PACKED' as const,
    actionTitle: 'Master Container Sealed & Packaged',
    actor: 'Nagesh Patil',
    stage: 'STATION_1_PACKAGING' as const,
    stageName: 'Station 1: Firewall & Packaging',
    entityId: 'BOX-20260901-DUM-001',
    entityType: 'BOX' as const,
    description: 'Master Container BOX-20260901-DUM-001 packed with 2 FG units of Dummy for testing (TEST-DUMMY-02).',
    statusAfter: 'In Warehouse',
    location: 'Takwe Plant Firewall Station 1'
  },
  {
    id: 'AUD-002',
    timestamp: '2026-09-01 11:30:00',
    actionType: 'FACTORY_DISPATCH_DIRECT' as const,
    actionTitle: 'Factory Direct OEM Dispatch',
    actor: 'Dadasaheb',
    stage: 'STATION_2_FACTORY_DISPATCH' as const,
    stageName: 'Station 2: Factory Dispatch',
    entityId: 'SAP-INV-98102',
    entityType: 'DISPATCH' as const,
    description: 'Direct OEM dispatch confirmed under SAP Invoice SAP-INV-98102 to CEP - Craiova Engine / FWSTA /95 | ROMANIA. Vehicle: MH-12-RN-4890.',
    statusAfter: 'In Transit / Delivered to Customer',
    location: 'Takwe Plant Outbound Dock'
  },
  {
    id: 'AUD-003',
    timestamp: '2026-09-02 14:11:00',
    actionType: 'BOX_PACKED' as const,
    actionTitle: 'Master Container Sealed & Packaged',
    actor: 'Nagesh Patil',
    stage: 'STATION_1_PACKAGING' as const,
    stageName: 'Station 1: Firewall & Packaging',
    entityId: 'BOX-20260902-PTH-002',
    entityType: 'BOX' as const,
    description: 'Master Container BOX-20260902-PTH-002 packed with ETB Panther (Export) (ETB-PTH-EXP).',
    statusAfter: 'In Warehouse',
    location: 'Takwe Plant Firewall Station 1'
  },
  {
    id: 'AUD-004',
    timestamp: '2026-09-03 10:22:20',
    actionType: 'BOX_PACKED' as const,
    actionTitle: 'Master Container Sealed & Packaged',
    actor: 'Nagesh Patil',
    stage: 'STATION_1_PACKAGING' as const,
    stageName: 'Station 1: Firewall & Packaging',
    entityId: 'BOX-20260903-FOX-003',
    entityType: 'BOX' as const,
    description: 'Master Container BOX-20260903-FOX-003 packed with ETB Fox Upgrade (Export) (ETB-FOX-UPG-EXP).',
    statusAfter: 'In Warehouse',
    location: 'Takwe Plant Firewall Station 1'
  },
  {
    id: 'AUD-005',
    timestamp: '2026-09-03 12:00:00',
    actionType: 'FACTORY_DISPATCH_INTERCOMPANY' as const,
    actionTitle: 'Inter-Plant Transfer Dispatch',
    actor: 'Dadasaheb',
    stage: 'STATION_2_FACTORY_DISPATCH' as const,
    stageName: 'Station 2: Factory Dispatch',
    entityId: 'SAP-IC-77401',
    entityType: 'DISPATCH' as const,
    description: 'Inter-plant transfer confirmed under SAP Invoice SAP-IC-77401 to European Logistics Hub. 2 Master containers dispatched.',
    statusAfter: 'In Transit',
    location: 'Takwe Plant Outbound Dock'
  },
  {
    id: 'AUD-006',
    timestamp: '2026-09-03 18:40:00',
    actionType: 'SISTER_CONCERN_RECEIVED' as const,
    actionTitle: 'Intake Scanned at Regional Hub',
    actor: 'Hans Schmidt',
    stage: 'STATION_3_SISTER_CONCERN' as const,
    stageName: 'Station 3: Inter-Plant Facility',
    entityId: 'BOX-20260903-FOX-003',
    entityType: 'BOX' as const,
    description: 'Master Container BOX-20260903-FOX-003 scanned upon arrival at European Logistics Hub (Germany).',
    statusAfter: 'In Warehouse of Inter-Plant Facility',
    location: 'European Logistics Hub (Germany)'
  },
  {
    id: 'AUD-007',
    timestamp: '2026-09-04 15:45:00',
    actionType: 'SISTER_CONCERN_DISPATCH' as const,
    actionTitle: 'Outbound Dispatch to OEM Customer',
    actor: 'Hans Schmidt',
    stage: 'STATION_3_SISTER_CONCERN' as const,
    stageName: 'Station 3: Inter-Plant Facility',
    entityId: 'SC-INV-2026-8802',
    entityType: 'SC_DISPATCH' as const,
    description: 'Facility delivery note SC-INV-2026-8802 confirmed to DEP - Dagenham Engine Panther Diesel / 0117A /144 | ENGLAND.',
    statusAfter: 'In Transit / Delivered to Customer',
    location: 'European Logistics Hub (Germany)'
  },
  {
    id: 'AUD-008',
    timestamp: '2026-09-08 07:46:10',
    actionType: 'BOX_PACKED' as const,
    actionTitle: 'Master Container Sealed & Packaged',
    actor: 'Nagesh Patil',
    stage: 'STATION_1_PACKAGING' as const,
    stageName: 'Station 1: Firewall & Packaging',
    entityId: 'BOX-20260908-FRD-004',
    entityType: 'BOX' as const,
    description: 'Master Container BOX-20260908-FRD-004 packed with FORD Sigma EDR-E Dragon (FORD-SIG-EDRE-DRG). Stored in factory stock.',
    statusAfter: 'In Warehouse',
    location: 'Takwe Plant Firewall Station 1'
  },
  {
    id: 'AUD-009',
    timestamp: '2026-09-09 08:31:00',
    actionType: 'BOX_PACKED' as const,
    actionTitle: 'Master Container Sealed & Packaged',
    actor: 'Nagesh Patil',
    stage: 'STATION_1_PACKAGING' as const,
    stageName: 'Station 1: Firewall & Packaging',
    entityId: 'BOX-20260909-DUM-005',
    entityType: 'BOX' as const,
    description: 'Master Container BOX-20260909-DUM-005 packed with 2 units of Dummy for testing (TEST-DUMMY-02). Ready in stock.',
    statusAfter: 'In Warehouse',
    location: 'Takwe Plant Firewall Station 1'
  }
];
