import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserAccount, UserRole, ActiveActor } from '../types';

export const PREDEFINED_USERS: UserAccount[] = [
  {
    id: 'usr_pack',
    name: 'Nagesh Patil',
    badgeId: 'FW-OP-101',
    role: 'packaging',
    roleTitle: 'Firewall Operator',
    department: 'Finished Goods Firewall & Packaging (Station 1)',
    stationName: 'Station 1: Firewall Inspection & Packaging',
    allowedActors: ['actor1', 'actor2', 'actor3', 'actor4', 'master', 'dashboard'],
    canAccessMasterData: true,
    avatarColor: 'bg-blue-600'
  },
  {
    id: 'usr_disp',
    name: 'Dadasaheb',
    badgeId: 'DISP-MGR-201',
    role: 'dispatch',
    roleTitle: 'Dispatch Manager',
    department: 'Outbound Logistics & Dispatch (Station 2)',
    stationName: 'Station 2: Outbound Shipping & Dispatch',
    allowedActors: ['actor1', 'actor2', 'actor3', 'actor4', 'master', 'dashboard'],
    canAccessMasterData: true,
    avatarColor: 'bg-indigo-600'
  },
  {
    id: 'usr_german',
    name: 'Hans Schmidt',
    badgeId: 'DE-HUB-301',
    role: 'plant_transfer',
    roleTitle: 'European Hub Logistics Specialist',
    department: 'European Logistics & Sister Concern Hub (Germany)',
    stationName: 'Station 3: Inter-Plant Transfer & Receiving (Germany Hub)',
    allowedActors: ['actor1', 'actor2', 'actor3', 'actor4', 'master', 'dashboard'],
    canAccessMasterData: true,
    avatarColor: 'bg-purple-600'
  },
  {
    id: 'usr_qa',
    name: 'Bhalchandra Bhalerao',
    badgeId: 'CQ-MGR-401',
    role: 'quality',
    roleTitle: 'Customer Quality',
    department: 'Customer Quality Engineering & Containment (Station 4)',
    stationName: 'Station 4: Customer Quality, Audit & Master Data',
    allowedActors: ['actor1', 'actor2', 'actor3', 'actor4', 'master', 'dashboard'],
    canAccessMasterData: true,
    avatarColor: 'bg-red-600'
  }
];

interface AuthContextType {
  currentUser: UserAccount | null;
  loginAs: (userId: string) => void;
  logout: () => void;
  allUsers: UserAccount[];
  canAccessActor: (actor: ActiveActor) => boolean;
  canAccessMasterData: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const AUTH_STORAGE_KEY = 'autotrace_current_user_v6';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    try {
      const saved = localStorage.getItem(AUTH_STORAGE_KEY);
      if (saved) {
        const found = PREDEFINED_USERS.find((u) => u.id === saved);
        if (found) return found;
      }
    } catch {}
    return PREDEFINED_USERS[0];
  });

  const loginAs = (userId: string) => {
    const user = PREDEFINED_USERS.find((u) => u.id === userId);
    if (user) {
      setCurrentUser(user);
      try {
        localStorage.setItem(AUTH_STORAGE_KEY, user.id);
      } catch {}
    }
  };

  const logout = () => {
    setCurrentUser(null);
    try {
      localStorage.removeItem(AUTH_STORAGE_KEY);
    } catch {}
  };

  // Open access: any user can do anything across all stations
  const canAccessActor = (_actor: ActiveActor): boolean => {
    return true;
  };

  const canAccessMasterData = true;

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        loginAs,
        logout,
        allUsers: PREDEFINED_USERS,
        canAccessActor,
        canAccessMasterData
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
