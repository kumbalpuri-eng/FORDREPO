import React, { useState } from 'react';
import { TraceabilityProvider, useTraceability } from './context/TraceabilityContext';
import { LanguageProvider, useLanguage } from './context/LanguageContext';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Sidebar } from './components/Sidebar';
import { Actor1Packaging } from './components/Actor1Packaging';
import { Actor2Dispatch } from './components/Actor2Dispatch';
import { Actor3SisterConcern } from './components/Actor3SisterConcern';
import { Actor4QA } from './components/Actor4QA';
import { Dashboard } from './components/Dashboard';
import { MasterDataModal } from './components/MasterDataModal';
import { RoleLoginModal } from './components/RoleLoginModal';
import { MobileScannerTerminal } from './components/MobileScannerTerminal';
import {
  Menu,
  Monitor,
  Smartphone,
  UserCheck,
  ChevronRight,
  ShieldCheck,
  ArrowRightLeft
} from 'lucide-react';

const MainContent: React.FC = () => {
  const { activeActor } = useTraceability();
  const { t, isGerman } = useLanguage();
  const { currentUser } = useAuth();

  // EXACTLY TWO OPTIONS AT THE TOP: Desktop version and Mobile version
  const [platformView, setPlatformView] = useState<'desktop' | 'mobile'>('desktop');

  // Modals & Navigation
  const [isMasterDataOpen, setIsMasterDataOpen] = useState<boolean>(false);
  const [masterDataTab, setMasterDataTab] = useState<'products' | 'customers' | 'logs'>('products');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState<boolean>(false);
  const [isRoleLoginOpen, setIsRoleLoginOpen] = useState<boolean>(false);

  const handleOpenMasterData = (tab: 'products' | 'customers' | 'logs' = 'products') => {
    setMasterDataTab(tab);
    setIsMasterDataOpen(true);
  };

  const stationLabels = {
    actor1: { name: t.actor1Label, subtitle: 'Packaging & Master Pallet QR' },
    actor2: { name: t.actor2Label, subtitle: 'Outbound Consignment Shipping' },
    actor3: { name: t.actor3Label, subtitle: 'Inter-Plant Facility Receiving & Dispatch' },
    actor4: { name: t.actor4Label, subtitle: 'Quality Containment & Genealogy' },
    dashboard: { name: isGerman ? 'Betriebs-Dashboard' : 'Plant Operations KPI', subtitle: 'Executive Analytics' }
  };

  const currentStation = stationLabels[activeActor] || stationLabels.actor1;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex font-sans antialiased">
      {/* Left-Hand Menu (All Access Provided From Here) */}
      <Sidebar
        onOpenMasterData={handleOpenMasterData}
        onOpenRoleLogin={() => setIsRoleLoginOpen(true)}
        isMobileOpen={isMobileSidebarOpen}
        setIsMobileOpen={setIsMobileSidebarOpen}
      />

      {/* Main Workspace Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen overflow-x-hidden">
        {/* Extremely Lean Top Bar: ONLY TWO OPTIONS AT TOP + Operator Profile */}
        <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-2xs">
          <div className="px-4 sm:px-6 h-14 flex items-center justify-between gap-3">
            {/* Left: Mobile Sidebar Toggle + Minimal Station Breadcrumb */}
            <div className="flex items-center gap-3 min-w-0">
              <button
                type="button"
                onClick={() => setIsMobileSidebarOpen(true)}
                className="lg:hidden p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                aria-label="Open Left Menu"
              >
                <Menu className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-2 min-w-0">
                <span className="text-xs font-bold text-slate-900 truncate">
                  {currentStation.name}
                </span>
                <span className="text-slate-300 hidden sm:inline">•</span>
                <span className="text-[11px] text-slate-500 truncate hidden md:inline">
                  {currentStation.subtitle}
                </span>
              </div>
            </div>

            {/* Center: EXACTLY TWO OPTIONS AT THE TOP */}
            <div className="flex items-center justify-center shrink-0">
              <div
                id="platform-version-selector"
                className="inline-flex p-1 bg-slate-100 rounded-lg border border-slate-200/90 shadow-2xs"
                role="group"
                aria-label="Application View Mode"
              >
                <button
                  type="button"
                  onClick={() => setPlatformView('desktop')}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                    platformView === 'desktop'
                      ? 'bg-white text-slate-900 shadow-xs ring-1 ring-slate-200'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  aria-pressed={platformView === 'desktop'}
                >
                  <Monitor className="w-4 h-4 text-blue-600" />
                  <span>Desktop version</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPlatformView('mobile')}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                    platformView === 'mobile'
                      ? 'bg-white text-slate-900 shadow-xs ring-1 ring-slate-200'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  aria-pressed={platformView === 'mobile'}
                >
                  <Smartphone className="w-4 h-4 text-emerald-600" />
                  <span>Mobile version</span>
                </button>
              </div>
            </div>

            {/* Right: Active Role Profile & Quick Switch */}
            <div className="flex items-center gap-2 shrink-0">
              {currentUser && (
                <button
                  type="button"
                  onClick={() => setIsRoleLoginOpen(true)}
                  className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs text-slate-700 transition-colors"
                  title="Switch Station / Operator Role"
                >
                  <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                  <span className="font-semibold text-slate-900 hidden sm:inline">
                    {currentUser.name}
                  </span>
                  <span className="text-[11px] text-slate-500 hidden md:inline">
                    ({currentUser.roleTitle})
                  </span>
                  <ArrowRightLeft className="w-3.5 h-3.5 text-slate-400 ml-0.5" />
                </button>
              )}
            </div>
          </div>
        </header>

        {/* Content Rendered Based On The 2 Top Options */}
        {platformView === 'desktop' ? (
          /* Desktop Workstation View - Open to all team members */
          <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            {activeActor === 'actor1' && <Actor1Packaging />}
            {activeActor === 'actor2' && <Actor2Dispatch />}
            {activeActor === 'actor3' && <Actor3SisterConcern />}
            {activeActor === 'actor4' && <Actor4QA />}
            {activeActor === 'dashboard' && <Dashboard />}
          </main>
        ) : (
          /* Mobile Handheld Scanner View - Open to all team members */
          <main className="flex-1 w-full max-w-md mx-auto px-3 py-4 flex flex-col">
            <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-xl border border-slate-800 flex-1 flex flex-col">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-5 h-5 text-emerald-400" />
                  <div>
                    <h3 className="text-sm font-bold text-white">Mobile Scanner Terminal</h3>
                    <p className="text-[11px] text-slate-400">Handheld Barcode / QR Station</p>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  ONLINE
                </span>
              </div>

              {/* Embedded Mobile Terminal */}
              <div className="flex-1 mt-4">
                <MobileScannerTerminal
                  isOpen={true}
                  onClose={() => setPlatformView('desktop')}
                  defaultMode={
                    activeActor === 'actor1'
                      ? 'pack'
                      : activeActor === 'actor2'
                      ? 'dispatch'
                      : activeActor === 'actor3'
                      ? 'sister'
                      : 'audit'
                  }
                />
              </div>
            </div>
          </main>
        )}

        {/* Ultra-lean compliance footer */}
        <footer className="bg-white border-t border-slate-200 py-3 text-xs text-slate-500 mt-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-2">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t.footerStandard}</span>
            </div>
            <div className="text-[11px] text-slate-400">
              {t.footerStatus}
            </div>
          </div>
        </footer>
      </div>

      {/* Role Login Modal */}
      <RoleLoginModal
        isOpen={isRoleLoginOpen}
        onClose={() => setIsRoleLoginOpen(false)}
      />

      {/* Master Data Modal (Accessible from left-hand menu for Quality Team) */}
      <MasterDataModal
        key={masterDataTab}
        isOpen={isMasterDataOpen}
        onClose={() => setIsMasterDataOpen(false)}
        defaultTab={masterDataTab}
      />
    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <TraceabilityProvider>
        <AuthProvider>
          <MainContent />
        </AuthProvider>
      </TraceabilityProvider>
    </LanguageProvider>
  );
}
