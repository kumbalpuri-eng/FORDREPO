import React, { useState } from 'react';
import { useTraceability } from '../context/TraceabilityContext';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { ActiveActor } from '../types';
import { COMPANY_INFO } from '../constants/company';
import {
  Package,
  Truck,
  Building2,
  ShieldAlert,
  Database,
  ChevronLeft,
  ChevronRight,
  Barcode,
  Globe,
  X,
  FileText,
  MapPin,
  LayoutDashboard,
  UserCheck,
  LogOut,
  Lock,
  Shield,
  Layers
} from 'lucide-react';

interface SidebarProps {
  onOpenMasterData: (tab?: 'products' | 'customers' | 'logs') => void;
  onOpenRoleLogin: () => void;
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  onOpenMasterData,
  onOpenRoleLogin,
  isMobileOpen,
  setIsMobileOpen
}) => {
  const {
    activeActor,
    setActiveActor,
    boxes,
    containmentNotices,
    auditLogs
  } = useTraceability();

  const { language, setLanguage, t, isGerman } = useLanguage();
  const { currentUser, canAccessActor, canAccessMasterData } = useAuth();

  const [isCollapsed, setIsCollapsed] = useState<boolean>(false);

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  const packedReadyBoxes = boxes.filter((b) => b.status === 'PACKED_IN_STOCK').length;
  const transferBoxes = boxes.filter(
    (b) => b.status === 'IN_TRANSIT_SISTER_CONCERN' || b.status === 'AT_SISTER_CONCERN'
  ).length;

  const allNavItems: {
    id: ActiveActor;
    label: string;
    stationNumber: string;
    role: string;
    icon: React.ReactNode;
    badge?: number;
    description: string;
  }[] = [
    {
      id: 'actor1',
      label: isGerman ? 'Station 1: Firewall & Verpackung' : 'Station 1: Firewall & Packaging',
      stationNumber: '1',
      role: isGerman ? 'Firewall-Inspektion' : 'Firewall & Box Packaging',
      icon: <Package className="w-4 h-4" />,
      badge: packedReadyBoxes > 0 ? packedReadyBoxes : undefined,
      description: isGerman ? 'Firewall FG-Scan' : 'Firewall FG Scan'
    },
    {
      id: 'actor2',
      label: isGerman ? 'Station 2: Warenausgang' : 'Station 2: Outbound Dispatch',
      stationNumber: '2',
      role: isGerman ? 'Versand & Zuordnung' : 'Consignment Shipping',
      icon: <Truck className="w-4 h-4" />,
      badge: packedReadyBoxes > 0 ? packedReadyBoxes : undefined,
      description: isGerman ? 'Lieferschein & Versand' : 'Shipping & Invoicing'
    },
    {
      id: 'actor3',
      label: isGerman ? 'Station 3: Transfer-Hub' : 'Station 3: Inter-Plant Transfer',
      stationNumber: '3',
      role: isGerman ? 'Hub-Wareneingang' : 'Facility Receiving',
      icon: <Building2 className="w-4 h-4" />,
      badge: transferBoxes > 0 ? transferBoxes : undefined,
      description: isGerman ? 'Regionaler Wareneingang' : 'Inter-Facility Hub'
    },
    {
      id: 'actor4',
      label: isGerman ? 'Station 4: Qualitätssicherung' : 'Station 4: Quality & Compliance',
      stationNumber: '4',
      role: isGerman ? 'Sperrung & Genealogie' : 'Genealogy & Containment',
      icon: <ShieldAlert className="w-4 h-4" />,
      badge: containmentNotices.length > 0 ? containmentNotices.length : undefined,
      description: isGerman ? 'Chargensperre & Audit' : 'Containment & Audit'
    },
    {
      id: 'dashboard',
      label: isGerman ? 'Betriebs-Dashboard' : 'Plant Operations KPI',
      stationNumber: '0',
      role: isGerman ? 'Kennzahlen' : 'KPI Overview',
      icon: <LayoutDashboard className="w-4 h-4" />,
      description: isGerman ? 'Prozess-Überblick' : 'Operations Analytics'
    }
  ];

  // Filter navigation items strictly by active actor role permissions
  const permittedNavItems = allNavItems.filter((item) => canAccessActor(item.id));

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          onClick={() => setIsMobileOpen(false)}
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-40 lg:hidden"
        />
      )}

      {/* Main Sidebar */}
      <aside
        className={`fixed top-0 bottom-0 left-0 z-40 bg-slate-900 text-slate-100 flex flex-col border-r border-slate-800 transition-all duration-200 ease-in-out lg:static shrink-0 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        } ${isCollapsed ? 'w-18' : 'w-68'}`}
      >
        {/* Brand Header */}
        <div className="h-14 flex items-center justify-between px-3.5 border-b border-slate-800 shrink-0 bg-slate-950/70">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white shrink-0 shadow-xs">
              <Barcode className="w-4 h-4" />
            </div>

            {!isCollapsed && (
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-xs tracking-tight text-white uppercase truncate">
                    AUTOTRACE MES
                  </span>
                  <span className="px-1 py-0.2 rounded text-[8px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                    VDA
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 truncate">
                  Ford Automotive FG Trace
                </p>
              </div>
            )}
          </div>

          <div className="flex items-center">
            <button
              type="button"
              onClick={toggleCollapse}
              title={isCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
              className="hidden lg:flex w-7 h-7 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 items-center justify-center transition-colors"
            >
              {isCollapsed ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
            </button>
            <button
              type="button"
              onClick={() => setIsMobileOpen(false)}
              className="lg:hidden w-7 h-7 rounded-md text-slate-400 hover:text-white flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Operator Profile Box */}
        <div className="p-2.5 border-b border-slate-800 bg-slate-950/40 shrink-0">
          {currentUser ? (
            <div className="space-y-1.5">
              {!isCollapsed ? (
                <div className="flex items-start justify-between gap-2 p-2 rounded-lg bg-slate-800/80 border border-slate-700/60">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                      <span className="text-xs font-bold text-white truncate">
                        {currentUser.name} {currentUser.id === 'usr_german' && '🇩🇪'}
                      </span>
                    </div>
                    <p className="text-[11px] text-blue-300 font-medium truncate mt-0.5">{currentUser.roleTitle}</p>
                    <p className="text-[10px] font-mono text-slate-400 truncate">ID: {currentUser.badgeId}</p>
                  </div>
                  <button
                    type="button"
                    onClick={onOpenRoleLogin}
                    title="Switch Operator Login"
                    className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-700 transition-colors shrink-0"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={onOpenRoleLogin}
                  title={`Logged in: ${currentUser.name} (${currentUser.roleTitle}) - Click to switch`}
                  className="w-full flex items-center justify-center p-2 rounded-lg bg-slate-800 text-blue-400 hover:bg-slate-700 hover:text-white"
                >
                  <UserCheck className="w-4 h-4" />
                </button>
              )}
            </div>
          ) : (
            <button
              type="button"
              onClick={onOpenRoleLogin}
              className="w-full py-1.5 px-2 bg-blue-600 hover:bg-blue-500 text-white rounded-md text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <UserCheck className="w-3.5 h-3.5" />
              {!isCollapsed && <span>Operator Login</span>}
            </button>
          )}
        </div>

        {/* Scrollable Navigation Area */}
        <div className="flex-1 overflow-y-auto py-3 px-2 space-y-4 text-xs scrollbar-thin scrollbar-thumb-slate-800">
          {/* Permitted Stations */}
          <div className="space-y-1">
            {!isCollapsed && (
              <div className="px-2 pb-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                {isGerman ? 'Zugelassene Stationen' : 'Permitted Stations'}
              </div>
            )}

            <nav className="space-y-1" aria-label="Permitted Stations">
              {permittedNavItems.map((item) => {
                const isActive = activeActor === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setActiveActor(item.id);
                      setIsMobileOpen(false);
                    }}
                    title={`${item.label} (${item.role})`}
                    className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left transition-all ${
                      isActive
                        ? 'bg-blue-600 text-white font-semibold shadow-xs'
                        : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                    }`}
                  >
                    <span className="shrink-0">{item.icon}</span>

                    {!isCollapsed ? (
                      <div className="min-w-0 flex-1 leading-tight">
                        <div className="flex items-center justify-between gap-1">
                          <p className="text-xs truncate font-medium">{item.label}</p>
                          {typeof item.badge === 'number' && (
                            <span
                              className={`px-1.5 py-0.2 rounded-full text-[9px] font-bold ${
                                isActive ? 'bg-white text-blue-700' : 'bg-slate-800 text-blue-400'
                              }`}
                            >
                              {item.badge}
                            </span>
                          )}
                        </div>
                        <p className="text-[10px] opacity-70 truncate mt-0.5">{item.description}</p>
                      </div>
                    ) : (
                      typeof item.badge === 'number' && (
                        <span className="w-2 h-2 rounded-full bg-blue-400 shrink-0" />
                      )
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Master Data: RESTRICTED TO QUALITY TEAM ONLY */}
          {canAccessMasterData ? (
            <div className="space-y-1 pt-3 border-t border-slate-800/80">
              {!isCollapsed && (
                <div className="px-2 pb-1 flex items-center justify-between text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                  <span>{isGerman ? 'Qualitäts-Stammdaten' : 'Quality Master Data'}</span>
                  <span className="text-emerald-400 font-mono text-[9px]">QA ONLY</span>
                </div>
              )}

              {/* Master Data CRUD */}
              <button
                type="button"
                onClick={() => {
                  onOpenMasterData('products');
                  setIsMobileOpen(false);
                }}
                title={t.masterDataBtn}
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors"
              >
                <Database className="w-4 h-4 text-emerald-400 shrink-0" />
                {!isCollapsed && (
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium text-slate-200 truncate">
                      {isGerman ? 'Produkt- & Kundenstamm' : 'Master Specifications'}
                    </p>
                    <p className="text-[10px] text-slate-400 truncate">
                      {isGerman ? 'Teile & OEM-Stammdaten' : 'Parts, capacities & OEM'}
                    </p>
                  </div>
                )}
              </button>

              {/* Audit Trail & Compliance Logs */}
              <button
                type="button"
                onClick={() => {
                  onOpenMasterData('logs');
                  setIsMobileOpen(false);
                }}
                title="Audit Trail Logs"
                className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-left text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors"
              >
                <FileText className="w-4 h-4 text-blue-400 shrink-0" />
                {!isCollapsed && (
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-medium text-slate-200 truncate">
                        {isGerman ? 'Audit-Protokolle' : 'Audit Trail Logs'}
                      </p>
                      <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-slate-800 text-slate-400">
                        {auditLogs.length}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 truncate">
                      {isGerman ? 'Rückverfolgbarkeit' : 'Immutable Action Log'}
                    </p>
                  </div>
                )}
              </button>
            </div>
          ) : (
            /* Locked indicator for non-quality operators */
            !isCollapsed && (
              <div className="pt-3 border-t border-slate-800/80 px-2 py-2 bg-slate-950/40 rounded-lg text-[10px] text-slate-500 flex items-center gap-1.5">
                <Lock className="w-3 h-3 text-slate-500 shrink-0" />
                <span>Master Data locked to QA Team</span>
              </div>
            )
          )}

          {/* Language Switcher in Sidebar */}
          <div className="pt-3 border-t border-slate-800/80">
            {!isCollapsed ? (
              <div className="px-2 space-y-1.5">
                <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                  <Globe className="w-3 h-3 text-slate-400" />
                  <span>{isGerman ? 'Systemsprache' : 'System Language'}</span>
                </div>
                <div className="grid grid-cols-2 gap-1 bg-slate-950 p-1 rounded-md border border-slate-800">
                  <button
                    type="button"
                    onClick={() => setLanguage('en')}
                    className={`py-1 rounded text-[11px] font-semibold transition-all ${
                      language === 'en'
                        ? 'bg-blue-600 text-white shadow-2xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    EN
                  </button>
                  <button
                    type="button"
                    onClick={() => setLanguage('de')}
                    className={`py-1 rounded text-[11px] font-semibold transition-all ${
                      language === 'de'
                        ? 'bg-blue-600 text-white shadow-2xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    DE
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex justify-center">
                <button
                  type="button"
                  onClick={() => setLanguage(language === 'en' ? 'de' : 'en')}
                  className="w-7 h-7 rounded text-[10px] font-bold bg-slate-800 text-slate-300 hover:text-white"
                  title="Toggle Language EN / DE"
                >
                  {language.toUpperCase()}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Minimal Footer */}
        <div className="p-2.5 border-t border-slate-800 bg-slate-950/80 shrink-0 text-[10px] text-slate-500 flex items-center justify-between">
          {!isCollapsed ? (
            <>
              <div className="flex items-center gap-1.5 truncate">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0" />
                <span className="truncate">{COMPANY_INFO.name}</span>
              </div>
              <span className="font-mono text-[9px] text-slate-400">IATF 16949</span>
            </>
          ) : (
            <div className="w-full flex justify-center">
              <span className="w-2 h-2 rounded-full bg-emerald-400" title="System Certified" />
            </div>
          )}
        </div>
      </aside>
    </>
  );
};
