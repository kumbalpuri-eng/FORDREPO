import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useTraceability } from '../context/TraceabilityContext';
import { UserAccount, ActiveActor } from '../types';
import {
  Shield,
  Package,
  Truck,
  Building2,
  ShieldAlert,
  Sliders,
  CheckCircle2,
  Lock,
  UserCheck,
  X,
  ArrowRight,
  Database
} from 'lucide-react';

interface RoleLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RoleLoginModal: React.FC<RoleLoginModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, loginAs, allUsers } = useAuth();
  const { setActiveActor } = useTraceability();

  if (!isOpen) return null;

  const handleSelectUser = (user: UserAccount) => {
    loginAs(user.id);
    // Auto route to their first allowed station
    const targetActor: ActiveActor = user.allowedActors[0] || 'actor1';
    setActiveActor(targetActor);
    onClose();
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'packaging':
        return <Package className="w-5 h-5 text-blue-600" />;
      case 'dispatch':
        return <Truck className="w-5 h-5 text-indigo-600" />;
      case 'plant_transfer':
        return <Building2 className="w-5 h-5 text-purple-600" />;
      case 'quality':
      default:
        return <ShieldAlert className="w-5 h-5 text-red-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/70">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center shadow-xs">
              <Shield className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 tracking-tight">
                Role-Based Operator Access
              </h2>
              <p className="text-xs text-slate-500">
                Select your station profile to log in with role-restricted permissions
              </p>
            </div>
          </div>
          {currentUser && (
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 flex items-center justify-center transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Roles List */}
        <div className="p-6 overflow-y-auto space-y-3">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider px-1">
            Available Station Personnel
          </div>

          <div className="space-y-2.5">
            {allUsers.map((u) => {
              const isCurrent = currentUser?.id === u.id;
              return (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => handleSelectUser(u)}
                  className={`w-full text-left p-4 rounded-xl border transition-all flex items-start justify-between gap-4 group ${
                    isCurrent
                      ? 'bg-blue-50/60 border-blue-300 ring-2 ring-blue-500/20'
                      : 'bg-white border-slate-200 hover:border-slate-300 hover:bg-slate-50/80 shadow-2xs'
                  }`}
                >
                  <div className="flex items-start gap-3.5 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                      {getRoleIcon(u.role)}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900">{u.name}</span>
                        {u.id === 'usr_german' && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-amber-50 text-amber-800 border border-amber-200 flex items-center gap-1">
                            🇩🇪 German Team
                          </span>
                        )}
                        <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                          {u.badgeId}
                        </span>
                        {isCurrent && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 border border-blue-200 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            Active
                          </span>
                        )}
                      </div>

                      <p className="text-xs font-semibold text-slate-700 mt-0.5">{u.roleTitle}</p>
                      <p className="text-[11px] text-slate-500 truncate">{u.department}</p>

                      {/* Access tags */}
                      <div className="flex flex-wrap items-center gap-1.5 mt-2">
                        <span className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                          {u.stationName}
                        </span>
                        {u.canAccessMasterData ? (
                          <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1">
                            <Database className="w-2.5 h-2.5" />
                            Master Data Access
                          </span>
                        ) : (
                          <span className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-slate-50 text-slate-400 border border-slate-100 flex items-center gap-1">
                            <Lock className="w-2.5 h-2.5" />
                            No Master Access
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="shrink-0 pt-1">
                    <div className="w-7 h-7 rounded-lg bg-slate-100 text-slate-500 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Footer info */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 text-[11px] text-slate-500 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <UserCheck className="w-3.5 h-3.5 text-blue-600" />
            <span>Role-Based Access Control (RBAC) Enforced</span>
          </span>
          <span className="text-slate-400">Master Data restricted to Customer Quality</span>
        </div>
      </div>
    </div>
  );
};
