import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Comprehensive global camera & video surface lifecycle safeguards
if (typeof window !== 'undefined') {
  // 1. Prototype protection for HTMLVideoElement play/pause promises to eliminate "play() interrupted by pause()"
  if (typeof HTMLVideoElement !== 'undefined') {
    const originalPlay = HTMLVideoElement.prototype.play;
    const originalPause = HTMLVideoElement.prototype.pause;

    HTMLVideoElement.prototype.play = function play() {
      try {
        const result = originalPlay.apply(this);
        if (result && typeof result.catch === 'function') {
          const guardedPromise = result.catch((err: unknown) => {
            const e = err as { name?: string; message?: string };
            const msg = e?.message || String(err || '');
            if (
              e?.name === 'AbortError' ||
              msg.includes('interrupted') ||
              msg.includes('pause') ||
              msg.includes('removed from the document') ||
              msg.includes('RenderedCameraImpl') ||
              msg.includes('onabort')
            ) {
              return;
            }
            throw err;
          });
          (this as unknown as { __activePlayPromise?: Promise<void> }).__activePlayPromise = guardedPromise;
          return guardedPromise;
        }
        return result;
      } catch (err: unknown) {
        const e = err as { name?: string; message?: string };
        const msg = e?.message || String(err || '');
        if (
          e?.name === 'AbortError' ||
          msg.includes('interrupted') ||
          msg.includes('pause') ||
          msg.includes('removed from the document')
        ) {
          return Promise.resolve();
        }
        throw err;
      }
    };

    HTMLVideoElement.prototype.pause = function pause() {
      const activePromise = (this as unknown as { __activePlayPromise?: Promise<void> }).__activePlayPromise;
      if (activePromise) {
        activePromise
          .then(() => {
            try {
              originalPause.apply(this);
            } catch {}
          })
          .catch(() => {});
      } else {
        try {
          originalPause.apply(this);
        } catch {}
      }
    };
  }

  // 2. Global Unhandled Rejection interceptor
  window.addEventListener(
    'unhandledrejection',
    (event) => {
      const reason = event.reason;
      const reasonStr = String(reason?.message || reason || '');
      if (
        reason?.name === 'AbortError' ||
        reasonStr.includes('RenderedCameraImpl') ||
        reasonStr.includes('video surface onabort') ||
        reasonStr.includes('onabort() called') ||
        reasonStr.includes('interrupted') ||
        reasonStr.includes('pause') ||
        reasonStr.includes('removed from the document') ||
        reasonStr.includes('Cannot transition to a new state') ||
        reasonStr.includes('already under transition') ||
        reasonStr.includes('Html5Qrcode')
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    },
    true
  );

  // 3. Global Error Event interceptor
  window.addEventListener(
    'error',
    (event) => {
      const msg = String(event.message || event.error?.message || event.error || '');
      if (
        msg.includes('RenderedCameraImpl') ||
        msg.includes('video surface onabort') ||
        msg.includes('onabort() called') ||
        msg.includes('interrupted') ||
        msg.includes('pause') ||
        msg.includes('Cannot transition to a new state') ||
        msg.includes('already under transition') ||
        msg.includes('Html5Qrcode')
      ) {
        event.preventDefault();
        event.stopImmediatePropagation();
        return true;
      }
    },
    true
  );

  // 4. Fallback window.onerror handler
  const prevOnError = window.onerror;
  window.onerror = function (message, source, lineno, colno, error) {
    const msg = String(message || error?.message || '');
    if (
      msg.includes('RenderedCameraImpl') ||
      msg.includes('video surface onabort') ||
      msg.includes('onabort() called') ||
      msg.includes('interrupted') ||
      msg.includes('pause') ||
      msg.includes('AbortError')
    ) {
      return true;
    }
    if (typeof prevOnError === 'function') {
      return prevOnError.call(this, message, source, lineno, colno, error);
    }
    return false;
  };
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

