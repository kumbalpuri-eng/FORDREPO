export type Language = 'en' | 'de';

export interface Translations {
  // Navigation & Common
  appTitle: string;
  appBadge: string;
  appSubtitle: string;
  masterDataBtn: string;
  languageSelect: string;
  langEn: string;
  langDe: string;
  
  // Workflow strip
  workflowTitle: string;
  step1Short: string;
  step2Short: string;
  step3Short: string;
  step4Short: string;

  // Actor tabs
  actor1Label: string;
  actor1Role: string;
  actor2Label: string;
  actor2Role: string;
  actor3Label: string;
  actor3Role: string;
  actor4Label: string;
  actor4Role: string;

  // Actor 3: Sister Concern (Special focus)
  actor3Badge: string;
  actor3Title: string;
  actor3Subtitle: string;
  actor3HubLocationBadge: string;
  actor3LangIndicator: string;
  actor3ConnectScanner: string;
  actor3Section1Title: string;
  actor3FinalCustomerLabel: string;
  actor3InvoiceNumberLabel: string;
  actor3InvoicePlaceholder: string;
  actor3DispatchDateLabel: string;
  actor3VehicleLabel: string;
  actor3VehiclePlaceholder: string;
  actor3NotesLabel: string;
  actor3NotesPlaceholder: string;
  actor3Section2Title: string;
  actor3BoxesSelectedInfo: string;
  actor3ScanBoxPlaceholder: string;
  actor3AddBoxBtn: string;
  actor3AvailableInventoryTitle: string;
  actor3NoStockMsg: string;
  actor3NoStockSub: string;
  actor3ExecuteDispatchBtn: string;
  actor3RecentDispatchesTitle: string;
  actor3NoDispatchesYet: string;
  actor3ViewPackingListBtn: string;
  actor3BoxAlreadyAdded: string;
  actor3BoxNotFound: string;
  actor3BoxNotAtSisterConcern: string;
  actor3SelectCustomerError: string;
  actor3EnterInvoiceError: string;
  actor3SelectBoxesError: string;

  // Packing list modal & document
  packingListTitle: string;
  packingListSub: string;
  packingListPrintBtn: string;
  packingListCloseBtn: string;
  packingListLangToggle: string;
  packingListLangDe: string;
  packingListLangEn: string;
  packingListLangDual: string;
  docSisterConcernHeader: string;
  docFactoryHeader: string;
  docSisterConcernSub: string;
  docFactorySub: string;
  docOfficialTitle: string;
  docScanVerification: string;
  docConsigneeLabel: string;
  docInvoiceNoLabel: string;
  docDispatchDateLabel: string;
  docDispatchNatureLabel: string;
  docNatureDirect: string;
  docNatureIntercompany: string;
  docNatureSisterConcern: string;
  docVehicleLabel: string;
  docFactoryRefLabel: string;
  docBoxesSerialsTitle: string;
  docBoxesTotalSummary: string;
  docTablePos: string;
  docTableBoxId: string;
  docTableProduct: string;
  docTableQty: string;
  docTableSerials: string;
  docGrandTotal: string;
  docTraceabilityVerified: string;
  docDispatchNotesLabel: string;
  docDefaultNotes: string;
  docPreparedBy: string;
  docAuthStamp: string;
  docFooterNote: string;

  // Actor 1 Packaging
  actor1Badge: string;
  actor1Title: string;
  actor1Subtitle: string;
  actor1SelectProduct: string;
  actor1ProdDate: string;
  actor1ProdShift: string;
  actor1ShiftA: string;
  actor1ShiftB: string;
  actor1ShiftC: string;
  actor1ScanFgSerial: string;
  actor1ScanPlaceholder: string;
  actor1AddSerialBtn: string;
  actor1ConnectScanner: string;
  actor1BoxProgress: string;
  actor1PackedOf: string;
  actor1PackAndGenerateQR: string;
  actor1RecentBoxes: string;
  actor1ViewLabel: string;
  actor1Pieces: string;

  // Actor 2 Factory Dispatch
  actor2Badge: string;
  actor2Title: string;
  actor2Subtitle: string;
  actor2DispatchType: string;
  actor2TypeDirect: string;
  actor2TypeSister: string;
  actor2InvoiceNo: string;
  actor2CustomerRecipient: string;
  actor2SisterConcernHub: string;
  actor2AvailableFactoryStock: string;
  actor2ExecuteDispatch: string;
  actor2RecentFactoryDispatches: string;

  // Actor 4 QA
  actor4Badge: string;
  actor4Title: string;
  actor4Subtitle: string;
  actor4SearchModeSerial: string;
  actor4SearchModeDate: string;
  actor4SearchBtn: string;
  actor4ExportCSV: string;
  actor4IssueNotice: string;
  actor4AuditTrail: string;

  // Footer
  footerStandard: string;
  footerStatus: string;
}

export const translations: Record<Language, Translations> = {
  en: {
    appTitle: 'AUTOTRACE',
    appBadge: 'Automotive FG Traceability',
    appSubtitle: 'End-to-End Serial & Mother QR Dispatch System',
    masterDataBtn: 'Product & Box Capacity Master',
    languageSelect: 'Language',
    langEn: 'English',
    langDe: 'Deutsch',

    workflowTitle: 'Automotive Traceability Pipeline:',
    step1Short: '1. Packaging & Master QR',
    step2Short: '2. Outbound Dispatch',
    step3Short: '3. Inter-Plant Receiving',
    step4Short: '4. Quality & Containment',

    actor1Label: 'Packaging & Master Labeling',
    actor1Role: 'Station 1: Line Packaging',
    actor2Label: 'Outbound Dispatch & Shipping',
    actor2Role: 'Station 2: Consignment Dispatch',
    actor3Label: 'Inter-Plant Facility Receiving',
    actor3Role: 'Station 3: Facility Logistics Hub',
    actor4Label: 'Quality Assurance & Containment',
    actor4Role: 'Station 4: Compliance & Genealogy',

    // Station 3: Inter-Plant Facility Receiving
    actor3Badge: 'STATION 3',
    actor3Title: 'Inter-Plant Facility Receiving & Dispatch Hub',
    actor3Subtitle: 'Central facility receiving portal: Receive factory transferred containers, allocate consignments to OEM customers, and issue official dispatch manifests.',
    actor3HubLocationBadge: 'Inter-Plant Regional Logistics Hub (DE / European Hub)',
    actor3LangIndicator: 'Facility Portal Language:',
    actor3ConnectScanner: 'Scan / Verify Container QR',
    actor3Section1Title: '1. Consignment Assignment & Outbound Invoicing',
    actor3FinalCustomerLabel: 'Assign Consignee / OEM Customer *',
    actor3InvoiceNumberLabel: 'Facility Dispatch Invoice / Delivery Note Number *',
    actor3InvoicePlaceholder: 'e.g. WH-INV-2026-9041',
    actor3DispatchDateLabel: 'Dispatch Date',
    actor3VehicleLabel: 'Vehicle / Logistics Carrier',
    actor3VehiclePlaceholder: 'e.g. KA-04-E-7890 or Spedition Müller',
    actor3NotesLabel: 'Dispatch Notes / Consignment Remarks',
    actor3NotesPlaceholder: 'Dispatched from Inter-Plant Facility Hub to Final OEM Customer',
    actor3Section2Title: '2. Scan Master Containers to Dispatch to this Consignee',
    actor3BoxesSelectedInfo: '{count} Containers Selected ({units} FG Units)',
    actor3ScanBoxPlaceholder: 'Scan or enter Master Container ID (e.g. BOX-20260901-...)',
    actor3AddBoxBtn: 'Add Container',
    actor3AvailableInventoryTitle: 'Available Facility Inventory ({count} Master Units in Stock)',
    actor3NoStockMsg: 'No containers currently in Facility Hub inventory.',
    actor3NoStockSub: 'Dispatch containers from Plant (Station 2) using "Inter-Plant Facility Transfer" to populate stock here.',
    actor3ExecuteDispatchBtn: 'Execute Outbound Dispatch & Generate Packing List',
    actor3RecentDispatchesTitle: 'Recent Dispatches from Facility Hub',
    actor3NoDispatchesYet: 'No customer dispatches executed from Facility Hub yet.',
    actor3ViewPackingListBtn: 'View Packing List',
    actor3BoxAlreadyAdded: 'Container {id} is already added to this consignment.',
    actor3BoxNotFound: 'Container "{id}" not found in system.',
    actor3BoxNotAtSisterConcern: 'Container {id} is in status "{status}". Only containers in "In Transit / Inter-Plant Hub" can be dispatched here.',
    actor3SelectCustomerError: 'Please select the final customer for this shipment.',
    actor3EnterInvoiceError: 'Please enter the Facility Dispatch Invoice / Delivery Note Number.',
    actor3SelectBoxesError: 'Please scan or select at least one container from facility inventory.',

    // Packing List Modal
    packingListTitle: 'Automated Packing List / Dispatch Manifest',
    packingListSub: 'Generated automatically upon dispatch confirmation',
    packingListPrintBtn: 'Print Packing List',
    packingListCloseBtn: 'Close',
    packingListLangToggle: 'Document Language:',
    packingListLangDe: 'German (DE)',
    packingListLangEn: 'English (EN)',
    packingListLangDual: 'Dual (DE / EN)',
    docSisterConcernHeader: 'Inter-Plant Logistics Hub - Regional Distribution',
    docFactoryHeader: 'Automotive Precision Components Manufacturing Ltd.',
    docSisterConcernSub: 'Logistics Center & Regional Hub • Inter-Plant Distribution Hub • IATF 16949 / VDA 6.1',
    docFactorySub: 'Central Automotive Plant, Industrial Area Phase II • ISO/IATF 16949 Certified Plant',
    docOfficialTitle: 'Official Dispatch Packing List & Traceability Manifest',
    docScanVerification: 'Scan for Verification',
    docConsigneeLabel: 'Consignee / Customer Details:',
    docInvoiceNoLabel: 'Invoice / Challan No:',
    docDispatchDateLabel: 'Dispatch Date:',
    docDispatchNatureLabel: 'Dispatch Nature:',
    docNatureDirect: 'Direct OEM Consignment Sale',
    docNatureIntercompany: 'Inter-Plant Transfer (Central Plant to Regional Facility)',
    docNatureSisterConcern: 'Regional Facility Dispatch to Customer',
    docVehicleLabel: 'Vehicle / Transporter:',
    docFactoryRefLabel: 'Original Plant Invoice Ref:',
    docBoxesSerialsTitle: 'Dispatched Master Containers & FG QR Code Serial Numbers',
    docBoxesTotalSummary: 'Total: {boxes} Containers ({units} Finished Goods Units)',
    docTablePos: '#',
    docTableBoxId: 'Master Container QR ID',
    docTableProduct: 'Product Description & Part No',
    docTableQty: 'Packed Qty',
    docTableSerials: 'Enclosed FG QR Serial Numbers',
    docGrandTotal: 'Grand Total Units Dispatched:',
    docTraceabilityVerified: '100% Traceability Verified',
    docDispatchNotesLabel: 'Dispatch Notes / Instructions:',
    docDefaultNotes: 'Ensure careful handling. Fragile precision automotive components. Check master QR seal integrity on receipt.',
    docPreparedBy: 'Prepared & Checked By',
    docAuthStamp: 'Authorized Logistics Stamp',
    docFooterNote: 'Official Traceability Packing List • IATF 16949 Traceability Standard',

    // Station 1
    actor1Badge: 'STATION 1',
    actor1Title: 'Firewall Inspection & Box Packaging Station',
    actor1Subtitle: 'Firewall Operator station: scan finished goods QR serials into standard boxes up to maximum capacity and generate Master Container QR codes.',
    actor1SelectProduct: 'Select Product Specification',
    actor1ProdDate: 'Production Date',
    actor1ProdShift: 'Production Shift',
    actor1ShiftA: 'Shift A (Morning)',
    actor1ShiftB: 'Shift B (Afternoon)',
    actor1ShiftC: 'Shift C (Night)',
    actor1ScanFgSerial: 'Scan / Enter FG QR Serial Number',
    actor1ScanPlaceholder: 'Scan FG QR code (e.g. FG-PTH-20260908-001)',
    actor1AddSerialBtn: 'Add Serial',
    actor1ConnectScanner: 'Connect Camera Scanner',
    actor1BoxProgress: 'Master Container Filling Progress',
    actor1PackedOf: '{packed} of {capacity} items scanned',
    actor1PackAndGenerateQR: 'Seal Container & Generate Master Pallet QR',
    actor1RecentBoxes: 'Recently Packed Master Units',
    actor1ViewLabel: 'View Label',
    actor1Pieces: 'pieces',

    // Station 2
    actor2Badge: 'STATION 2',
    actor2Title: 'Outbound Dispatch & Shipping Consignment Station',
    actor2Subtitle: 'Select consignment routing: Direct OEM customer dispatch or Inter-Plant Facility Transfer.',
    actor2DispatchType: 'Dispatch Destination Routing',
    actor2TypeDirect: 'Direct OEM Customer Consignment',
    actor2TypeSister: 'Inter-Plant Facility Transfer',
    actor2InvoiceNo: 'Commercial Invoice / Delivery Note Number',
    actor2CustomerRecipient: 'Consignee / Recipient',
    actor2SisterConcernHub: 'Inter-Plant Regional Hub',
    actor2AvailableFactoryStock: 'Available Finished Goods Stock (Packed & Ready)',
    actor2ExecuteDispatch: 'Execute Outbound Dispatch & Generate Packing List',
    actor2RecentFactoryDispatches: 'Recent Outbound Dispatches',

    // Station 4
    actor4Badge: 'STATION 4',
    actor4Title: 'QA Containment & Traceability Investigation',
    actor4Subtitle: 'Search any individual FG serial number or batch date to retrieve complete parent pallet, factory dispatch, and inter-facility customer genealogy.',
    actor4SearchModeSerial: 'Search by FG QR Serial',
    actor4SearchModeDate: 'Search by Production Date Range',
    actor4SearchBtn: 'Investigate Traceability',
    actor4ExportCSV: 'Export CSV Report',
    actor4IssueNotice: 'Issue Containment Notice',
    actor4AuditTrail: 'Historical Containment Notices (Audit Trail)',

    // Footer
    footerStandard: 'Automotive Finished Goods QR Traceability System • IATF 16949 Compliant',
    footerStatus: 'System Online • Dual Language (EN / DE) Enabled'
  },
  de: {
    appTitle: 'AUTOTRACE',
    appBadge: 'Automobil-Rückverfolgbarkeit (FG)',
    appSubtitle: 'End-to-End Seriennummern- & Gebinde-QR-Versandsystem',
    masterDataBtn: 'Stammdaten: Produkte & Gebindegrößen',
    languageSelect: 'Sprache',
    langEn: 'English',
    langDe: 'Deutsch',

    workflowTitle: 'Automobil-Rückverfolgbarkeits-Pipeline:',
    step1Short: '1. Verpackung & Master-QR',
    step2Short: '2. Warenausgang & Versand',
    step3Short: '3. Werkstransfer-Empfang',
    step4Short: '4. QS-Sperrung & Audit',

    actor1Label: 'Verpackung & Gebinde-Etikettierung',
    actor1Role: 'Station 1: Linienverpackung',
    actor2Label: 'Warenausgang & Versand',
    actor2Role: 'Station 2: Kundenauslieferung',
    actor3Label: 'Werkstransfer-Hub Empfang',
    actor3Role: 'Station 3: Logistik-Zwischenlager',
    actor4Label: 'Qualitätssicherung (QS)',
    actor4Role: 'Station 4: Chargensperrung & Genealogie',

    // Station 3: Inter-Plant (German)
    actor3Badge: 'STATION 3',
    actor3Title: 'Werkstransfer-Hub: Wareneingang & Kundenweiterleitung',
    actor3Subtitle: 'Zentrales Portal des Werkstransfers: Eingang von Werkslieferungen verwalten, an OEM-Endkunden zuweisen und automatisierte Lieferscheine erstellen.',
    actor3HubLocationBadge: 'Werkstransfer-Hub (Niederlassung Deutschland / EU-Logistik)',
    actor3LangIndicator: 'Sprache für Werkstransfer-Hub:',
    actor3ConnectScanner: 'Kamera-Scanner verbinden / Scannen',
    actor3Section1Title: '1. Kundenzuweisung & Lieferschein',
    actor3FinalCustomerLabel: 'Endkunden zuweisen (OEM) *',
    actor3InvoiceNumberLabel: 'Lieferschein- / Ausgangsrechnungs-Nr. des Transfer-Hubs *',
    actor3InvoicePlaceholder: 'z.B. WH-INV-2026-9041 oder LS-DE-8821',
    actor3DispatchDateLabel: 'Auslieferungsdatum',
    actor3VehicleLabel: 'Fahrzeug / Spedition',
    actor3VehiclePlaceholder: 'z.B. Spedition Dachser, LKW-S-4890',
    actor3NotesLabel: 'Versandhinweise / Speditionsbemerkungen',
    actor3NotesPlaceholder: 'Warenausgang aus regionalem Logistik-Hub an Endabnehmer (OEM)',
    actor3Section2Title: '2. Master-Gebinde (Umkartons) für diesen Kunden scannen',
    actor3BoxesSelectedInfo: '{count} Gebinde ausgewählt ({units} Fertigerzeugnisse)',
    actor3ScanBoxPlaceholder: 'Master-Gebinde-ID scannen oder eingeben (z.B. BOX-20260901-...)',
    actor3AddBoxBtn: 'Gebinde hinzufügen',
    actor3AvailableInventoryTitle: 'Verfügbarer Lagerbestand im Transfer-Hub ({count} Gebinde am Lager)',
    actor3NoStockMsg: 'Aktuell keine Gebinde im Lager des Transfer-Hubs vorhanden.',
    actor3NoStockSub: 'Versenden Sie Gebinde aus dem Werk (Station 2) mit "Werkstransfer", um den Bestand hier aufzubauen.',
    actor3ExecuteDispatchBtn: 'Warenausgang buchen & Lieferschein erstellen',
    actor3RecentDispatchesTitle: 'Kürzliche Warenausgänge des Transfer-Hubs',
    actor3NoDispatchesYet: 'Bisher wurden keine Warenausgänge aus dem Transfer-Hub gebucht.',
    actor3ViewPackingListBtn: 'Lieferschein / Packliste anzeigen',
    actor3BoxAlreadyAdded: 'Gebinde {id} wurde dieser Sendung bereits hinzugefügt.',
    actor3BoxNotFound: 'Gebinde "{id}" im System nicht gefunden.',
    actor3BoxNotAtSisterConcern: 'Gebinde {id} hat den Status "{status}". Nur Gebinde im Status "In Transit / Inter-Plant Hub" können hier versendet werden.',
    actor3SelectCustomerError: 'Bitte wählen Sie den Endkunden (OEM) für diese Lieferung aus.',
    actor3EnterInvoiceError: 'Bitte geben Sie die Lieferschein-/Rechnungsnummer des Hubs ein.',
    actor3SelectBoxesError: 'Bitte wählen oder scannen Sie mindestens ein Master-Gebinde aus dem Lagerbestand.',

    // Packing List Modal (German)
    packingListTitle: 'Automatisierter Lieferschein / Packliste',
    packingListSub: 'Automatisch bei Abschluss des Warenausgangs generiert',
    packingListPrintBtn: 'Packliste drucken',
    packingListCloseBtn: 'Schließen',
    packingListLangToggle: 'Dokumentensprache:',
    packingListLangDe: 'Deutsch (DE)',
    packingListLangEn: 'Englisch (EN)',
    packingListLangDual: 'Zweisprachig (DE / EN)',
    docSisterConcernHeader: 'Logistik-Distributionszentrum - Regionalhub',
    docFactoryHeader: 'Automotive Komponenten Fertigungswerk GmbH',
    docSisterConcernSub: 'Logistikzentrum Südwest, Industriestraße 12, 70565 Stuttgart • Distributionszentrum • IATF 16949 / VDA 6.1',
    docFactorySub: 'Zentralwerk für Präzisions-Automobilkomponenten • ISO/IATF 16949 zertifiziertes Werk',
    docOfficialTitle: 'Offizielle Packliste & Rückverfolgbarkeits-Manifest / Dispatch Packing List',
    docScanVerification: 'Scan zur Echtheitsprüfung',
    docConsigneeLabel: 'Warenempfänger / Kundendaten (Consignee):',
    docInvoiceNoLabel: 'Lieferschein-Nr. / Rechnung (Invoice No):',
    docDispatchDateLabel: 'Auslieferungsdatum (Dispatch Date):',
    docDispatchNatureLabel: 'Versandart (Dispatch Nature):',
    docNatureDirect: 'Direktlieferung an OEM-Kunden',
    docNatureIntercompany: 'Werkstransfer (Hauptwerk an Regional-Hub)',
    docNatureSisterConcern: 'Regional-Hub Warenausgang an Endkunden (OEM)',
    docVehicleLabel: 'Fahrzeug / Spedition (Transporter):',
    docFactoryRefLabel: 'Ursprüngliche Werksrechnung (Factory Ref):',
    docBoxesSerialsTitle: 'Versendete Master-Gebinde & FG-QR-Einzelseriennummern',
    docBoxesTotalSummary: 'Gesamt: {boxes} Gebinde ({units} Fertigerzeugnisse)',
    docTablePos: 'Pos.',
    docTableBoxId: 'Master-Gebinde-QR-ID (Box ID)',
    docTableProduct: 'Produktbezeichnung & Sachnummer (Part No)',
    docTableQty: 'Menge (Qty)',
    docTableSerials: 'Enthaltene FG-Einzelseriennummern (QR Serials)',
    docGrandTotal: 'Gesamtmenge versendet (Total Units):',
    docTraceabilityVerified: '100% lückenlose Rückverfolgbarkeit geprüft (IATF 16949)',
    docDispatchNotesLabel: 'Versandhinweise / Instruktionen (Dispatch Notes):',
    docDefaultNotes: 'Präzisions-Automobilteile. Vorsichtig behandeln. Unversehrtheit des Master-QR-Siegels bei Anlieferung prüfen.',
    docPreparedBy: 'Erstellt & Geprüft durch (Prepared By)',
    docAuthStamp: 'Logistik-Freigabestempel (Authorized Stamp)',
    docFooterNote: 'Offizielles Rückverfolgbarkeits-Dokument • Entspricht VDA 4913 & IATF 16949 Standard',

    // Station 1 (German)
    actor1Badge: 'STATION 1',
    actor1Title: 'Firewall-Inspektion & Kistenverpackungsstation',
    actor1Subtitle: 'Firewall-Operator-Station: Fertigwaren-QR-Codes scannen bis zur Kistenkapazität und Master-QR-Etiketten drucken.',
    actor1SelectProduct: 'Zu verpackendes Produkt auswählen',
    actor1ProdDate: 'Produktionsdatum',
    actor1ProdShift: 'Produktionsschicht',
    actor1ShiftA: 'Frühschicht (Schicht A)',
    actor1ShiftB: 'Spätschicht (Schicht B)',
    actor1ShiftC: 'Nachtschicht (Schicht C)',
    actor1ScanFgSerial: 'FG-QR-Seriennummer scannen / eingeben',
    actor1ScanPlaceholder: 'FG-QR-Code scannen (z.B. FG-PTH-20260908-001)',
    actor1AddSerialBtn: 'Seriennr. hinzufügen',
    actor1ConnectScanner: 'Kamera-Scanner verbinden',
    actor1BoxProgress: 'Befüllungsgrad des Master-Gebindes',
    actor1PackedOf: '{packed} von {capacity} Artikeln gescannt',
    actor1PackAndGenerateQR: 'Gebinde abschließen & Master-QR generieren',
    actor1RecentBoxes: 'Kürzlich gepackte Master-Gebinde',
    actor1ViewLabel: 'Etikett anzeigen',
    actor1Pieces: 'Stück',

    // Station 2 (German)
    actor2Badge: 'STATION 2',
    actor2Title: 'Werksausgang & Versandstation',
    actor2Subtitle: 'Wählen Sie, ob direkt an OEM-Kunden versendet wird oder ein Werkstransfer an den Regional-Hub erfolgt.',
    actor2DispatchType: 'Versandziel-Typ',
    actor2TypeDirect: 'Direktverkauf an OEM-Kunden',
    actor2TypeSister: 'Werkstransfer (an Regional-Hub)',
    actor2InvoiceNo: 'Werks-Lieferschein- / Rechnungsnummer',
    actor2CustomerRecipient: 'Kunde / Empfänger',
    actor2SisterConcernHub: 'Regionaler Logistik-Hub',
    actor2AvailableFactoryStock: 'Verfügbarer Werksbestand (Verpackt & Versandbereit)',
    actor2ExecuteDispatch: 'Werksausgang buchen & Lieferschein erstellen',
    actor2RecentFactoryDispatches: 'Kürzliche Werksausgänge',

    // Station 4 (German)
    actor4Badge: 'STATION 4',
    actor4Title: 'QS-Chargenrückverfolgung & Sperrmanagement',
    actor4Subtitle: 'Suchen Sie nach einer einzelnen Seriennummer oder einem Produktionszeitraum, um den gesamten Weg über Werksausgang, Transfer-Hub und Kunde nachzuvollziehen.',
    actor4SearchModeSerial: 'Suche nach FG-Seriennummer',
    actor4SearchModeDate: 'Suche nach Produktionsdatum',
    actor4SearchBtn: 'Rückverfolgung starten',
    actor4ExportCSV: 'CSV-Prüfbericht exportieren',
    actor4IssueNotice: 'Sperrmitteilung / Rückruf versenden',
    actor4AuditTrail: 'Historische Sperrmitteilungen (Audit-Trail)',

    // Footer
    footerStandard: 'Automobil-Rückverfolgbarkeitssystem für Fertigerzeugnisse • IATF 16949 / VDA 6.1 konform',
    footerStatus: 'System bereit • Zweisprachig (Deutsch / Englisch) aktiv'
  }
};
