import { Html5Qrcode, Html5QrcodeCameraScanConfig, Html5QrcodeScannerState } from 'html5-qrcode';

export type ScanSuccessCallback = (decodedText: string) => void;

// Register a global unhandled rejection handler to catch Chrome/Safari's
// asynchronous DOMException: "The play() request was interrupted because the media was removed from the document."
if (typeof window !== 'undefined' && !(window as unknown as { __SAFE_CAMERA_INTERRUPT_HANDLER__?: boolean }).__SAFE_CAMERA_INTERRUPT_HANDLER__) {
  (window as unknown as { __SAFE_CAMERA_INTERRUPT_HANDLER__?: boolean }).__SAFE_CAMERA_INTERRUPT_HANDLER__ = true;
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    const msg = reason?.message || String(reason || '');
    if (
      reason?.name === 'AbortError' ||
      msg.includes('interrupted') ||
      msg.includes('removed from the document')
    ) {
      // Prevent unhandled promise rejection error from bubbling to window / console monitors
      event.preventDefault();
    }
  });
}

/**
 * SafeCameraScanner prevents race conditions, crashes, and play() interruptions in html5-qrcode:
 * - Prevents "The play() request was interrupted because the media was removed from the document"
 * - Prevents "Cannot transition to a new state, already under transition"
 * - Serializes start() and stop() so they never overlap
 * - Queues stop() if requested while start() is initializing the camera
 * - Re-uses or cleanly recreates instances to avoid DOM/state corruption
 */
export class SafeCameraScanner {
  private elementId: string;
  private scanner: Html5Qrcode | null = null;
  private isStarting = false;
  private isStopping = false;
  private stopRequested = false;
  private currentStopPromise: Promise<void> | null = null;
  private activeFacingMode: 'environment' | 'user' = 'environment';
  private mutationObserver: MutationObserver | null = null;

  constructor(elementId: string) {
    this.elementId = elementId;
  }

  public get isRunning(): boolean {
    if (!this.scanner) return false;
    try {
      return this.scanner.getState() === Html5QrcodeScannerState.SCANNING;
    } catch {
      return false;
    }
  }

  /**
   * Automatically patch any <video> tag created inside the container so that its play() method
   * never produces an unhandled rejection when the element or container is removed from the DOM.
   */
  private installVideoPlayProtection(): void {
    const container = document.getElementById(this.elementId);
    if (!container) return;

    const patchVideo = (video: HTMLVideoElement) => {
      if ((video as unknown as { __playPatched?: boolean }).__playPatched) return;
      (video as unknown as { __playPatched?: boolean }).__playPatched = true;

      // Handle abort events directly on the video element to prevent RenderedCameraImpl onabort() errors
      video.onabort = (e) => {
        try {
          e?.stopPropagation?.();
          e?.stopImmediatePropagation?.();
        } catch {}
      };
      video.addEventListener(
        'abort',
        (e) => {
          try {
            e.stopPropagation();
            e.stopImmediatePropagation();
          } catch {}
        },
        { capture: true }
      );

      const originalPlay = video.play.bind(video);
      const originalPause = video.pause.bind(video);
      let pendingPlayPromise: Promise<void> | null = null;

      video.play = async () => {
        try {
          pendingPlayPromise = originalPlay();
          return await pendingPlayPromise;
        } catch (err: unknown) {
          const e = err as { name?: string; message?: string };
          const msg = e?.message || String(err || '');
          if (
            e?.name === 'AbortError' ||
            msg.includes('interrupted') ||
            msg.includes('pause') ||
            msg.includes('removed from the document') ||
            msg.includes('RenderedCameraImpl') ||
            msg.includes('onabort')
          ) {
            // Silently suppress the expected browser cancellation on unmount/stop
            return;
          }
          throw err;
        } finally {
          pendingPlayPromise = null;
        }
      };

      video.pause = () => {
        if (pendingPlayPromise) {
          pendingPlayPromise
            .then(() => {
              try {
                originalPause();
              } catch {}
            })
            .catch(() => {});
        } else {
          try {
            originalPause();
          } catch {}
        }
      };
    };

    // Patch any already-present video tags
    container.querySelectorAll('video').forEach(patchVideo);

    // Watch for newly inserted video tags by html5-qrcode
    if (this.mutationObserver) {
      this.mutationObserver.disconnect();
    }

    this.mutationObserver = new MutationObserver((mutations) => {
      for (const m of mutations) {
        for (const n of Array.from(m.addedNodes)) {
          if (n instanceof HTMLVideoElement) {
            patchVideo(n);
          } else if (n instanceof HTMLElement) {
            n.querySelectorAll('video').forEach(patchVideo);
          }
        }
      }
    });

    this.mutationObserver.observe(container, { childList: true, subtree: true });
  }

  /**
   * Explicitly stop camera media stream tracks without triggering premature pause()
   * on pending play() requests before html5-qrcode clears or unmounts the DOM.
   */
  private safelyHaltVideoStreams(): void {
    const container = document.getElementById(this.elementId);
    if (!container) return;

    const videos = container.querySelectorAll('video');
    videos.forEach((video) => {
      try {
        video.onabort = null;
        video.onerror = null;

        if (video.srcObject) {
          const stream = video.srcObject as MediaStream;
          if (stream && typeof stream.getTracks === 'function') {
            stream.getTracks().forEach((track) => {
              try {
                track.stop();
              } catch {
                // ignore
              }
            });
          }
          video.srcObject = null;
        }
      } catch {
        // ignore
      }
    });
  }

  /**
   * Safely start the camera scanner.
   * If a previous session is stopping, waits for it.
   * If fallbackToUserOnFail is true, cleanly creates a fresh instance for user camera if environment fails.
   */
  public async start(
    facingMode: 'environment' | 'user',
    config: Html5QrcodeCameraScanConfig,
    onScan: ScanSuccessCallback,
    fallbackToUserOnFail = true
  ): Promise<boolean> {
    this.stopRequested = false;
    this.activeFacingMode = facingMode;

    // Ensure any ongoing stop completes first
    if (this.currentStopPromise) {
      await this.currentStopPromise.catch(() => {});
    }

    // If already running or starting, stop cleanly first
    if (this.scanner || this.isStarting) {
      await this.stop();
    }

    if (this.stopRequested) {
      return false;
    }

    const container = document.getElementById(this.elementId);
    if (!container) {
      console.warn(`[SafeCameraScanner] Element #${this.elementId} not found in DOM.`);
      return false;
    }

    // Install play protection on the container before html5-qrcode starts
    this.installVideoPlayProtection();

    this.isStarting = true;

    try {
      const instance = new Html5Qrcode(this.elementId);
      this.scanner = instance;

      await instance.start(
        { facingMode },
        config,
        (decodedText) => {
          if (!this.stopRequested) {
            onScan(decodedText);
          }
        },
        () => {
          // ignore scan attempt errors (normal frame noise)
        }
      );

      this.isStarting = false;

      // If stop was requested while camera was initializing
      if (this.stopRequested) {
        await this.stop();
        return false;
      }

      return true;
    } catch (err: unknown) {
      this.isStarting = false;
      await this.cleanupInstance();

      if (this.stopRequested) {
        return false;
      }

      const e = err as { name?: string; message?: string };
      const msg = e?.message || String(err || '');
      // If error is play interrupted, don't cascade as a crash
      if (
        e?.name === 'AbortError' ||
        msg.includes('interrupted') ||
        msg.includes('removed from the document')
      ) {
        return false;
      }

      // Try fallback to front/user camera if rear/environment failed
      if (fallbackToUserOnFail && facingMode === 'environment') {
        console.warn('[SafeCameraScanner] Environment camera failed, trying fallback to user camera:', err);
        return this.start('user', config, onScan, false);
      }

      throw err;
    }
  }

  /**
   * Safely stop the camera.
   * If start() is in progress, flags stopRequested so it stops immediately upon start completion.
   * Never calls instance.stop() concurrently.
   */
  public async stop(): Promise<void> {
    this.stopRequested = true;

    if (this.currentStopPromise) {
      return this.currentStopPromise;
    }

    this.currentStopPromise = this.internalStop();
    try {
      await this.currentStopPromise;
    } finally {
      this.currentStopPromise = null;
    }
  }

  private async internalStop(): Promise<void> {
    if (this.mutationObserver) {
      this.mutationObserver.disconnect();
      this.mutationObserver = null;
    }

    // If starting is in progress, wait for start() to finish its transition
    while (this.isStarting) {
      await new Promise((r) => setTimeout(r, 40));
    }

    const instance = this.scanner;
    if (!instance) {
      this.safelyHaltVideoStreams();
      return;
    }

    this.isStopping = true;
    try {
      this.safelyHaltVideoStreams();

      let isScanning = false;
      try {
        isScanning = instance.getState() === Html5QrcodeScannerState.SCANNING;
      } catch {
        isScanning = instance.isScanning;
      }

      if (isScanning) {
        await instance.stop().catch((err) => {
          // Catch and ignore transition error gracefully
          console.warn('[SafeCameraScanner] Notice during stop():', err);
        });
      }

      try {
        instance.clear();
      } catch {
        // ignore clear error
      }
    } catch (e) {
      console.warn('[SafeCameraScanner] Error during stop sequence:', e);
    } finally {
      this.safelyHaltVideoStreams();
      this.scanner = null;
      this.isStopping = false;
    }
  }

  private async cleanupInstance(): Promise<void> {
    if (this.mutationObserver) {
      this.mutationObserver.disconnect();
      this.mutationObserver = null;
    }

    this.safelyHaltVideoStreams();

    if (this.scanner) {
      try {
        if (this.scanner.isScanning) {
          await this.scanner.stop().catch(() => {});
        }
      } catch {
        // ignore
      }
      try {
        this.scanner.clear();
      } catch {
        // ignore
      }
      this.scanner = null;
    }
  }

  public getFacingMode(): 'environment' | 'user' {
    return this.activeFacingMode;
  }
}
